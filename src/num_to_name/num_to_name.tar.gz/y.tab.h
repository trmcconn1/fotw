
typedef union  {int i;
	char *str;
	 } YYSTYPE;
extern YYSTYPE yylval;
# define COMMA 257
# define LITERAL 258
# define WHITESPACE 259
# define DIGIT 260
# define EDIGIT 261
# define EON 262
